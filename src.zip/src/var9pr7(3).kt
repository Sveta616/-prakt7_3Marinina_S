fun main()
{
    println("Введите сторону a прямоугольника")
    var a=readLine()!!.ToDouble()
    println("Введите сторону b прямоугольника")
    var b=readline()!!.ToDouble()
    var p=2*(a+b)
    var s=a*b

   when
   {
       (a>0&&b>0)->println("Периметр=$p", "Площадь=$s")
   }
}